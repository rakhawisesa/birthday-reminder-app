-- Adminer 4.8.1 MySQL 8.0.30 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `assessment-sdt` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `assessment-sdt`;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'default',
  `last_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'name',
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'email@default.com',
  `birthday_date` date NOT NULL DEFAULT (curdate()),
  `timezone_location` enum('andorra','dubai','kabul','tirane','yerevan','casey','davis','mawson','palmer','rothera','syowa','troll','vostok','buenos aires','cordoba','salta','jujuy','tucuman','catamarca','la rioja','san juan','mendoza','san luis','rio gallegos','ushuaia','pago pago','vienna','lord howe','macquarie','hobart','currie','melbourne','sydney','broken hill','brisbane','lindeman','adelaide','darwin','perth','eucla','baku','barbados','dhaka','brussels','sofia','bermuda','brunei','la paz','noronha','belem','fortaleza','recife','araguaina','maceio','bahia','sao paulo','campo grande','cuiaba','santarem','porto velho','boa vista','manaus','eirunepe','rio branco','nassau','thimphu','minsk','belize','st johns','halifax','glace bay','moncton','goose bay','blanc-sablon','toronto','nipigon','thunder bay','iqaluit','pangnirtung','atikokan','winnipeg','rainy river','resolute','rankin inlet','regina','swift current','edmonton','cambridge bay','yellowknife','inuvik','creston','dawson creek','fort nelson','vancouver','whitehorse','dawson','cocos','zurich','abidjan','rarotonga','santiago','punta arenas','easter','shanghai','urumqi','bogota','costa rica','havana','cape verde','curacao','christmas','nicosia','famagusta','prague','berlin','copenhagen','santo domingo','algiers','guayaquil','galapagos','tallinn','cairo','el aaiun','madrid','ceuta','canary','helsinki','fiji','stanley','chuuk','pohnpei','kosrae','faroe','paris','london','tbilisi','cayenne','accra','gibraltar','godthab','danmarkshavn','scoresbysund','thule','athens','south georgia','guatemala','guam','bissau','guyana','hong kong','tegucigalpa','port-au-prince','budapest','jakarta','pontianak','makassar','jayapura','dublin','jerusalem','kolkata','chagos','baghdad','tehran','reykjavik','rome','jamaica','amman','tokyo','nairobi','bishkek','tarawa','enderbury','kiritimati','pyongyang','seoul','almaty','qyzylorda','aqtobe','aqtau','atyrau','oral','beirut','colombo','monrovia','vilnius','luxembourg','riga','tripoli','casablanca','monaco','chisinau','majuro','kwajalein','yangon','ulaanbaatar','hovd','choibalsan','macau','martinique','malta','mauritius','maldives','mexico city','cancun','merida','monterrey','matamoros','mazatlan','chihuahua','ojinaga','hermosillo','tijuana','bahia banderas','kuala lumpur','kuching','maputo','windhoek','noumea','norfolk','lagos','managua','amsterdam','oslo','kathmandu','nauru','niue','auckland','chatham','panama','lima','tahiti','marquesas','gambier','port moresby','bougainville','manila','karachi','warsaw','miquelon','pitcairn','puerto rico','gaza','hebron','lisbon','madeira','azores','palau','asuncion','qatar','reunion','bucharest','belgrade','kaliningrad','moscow','simferopol','kirov','astrakhan','volgograd','saratov','ulyanovsk','samara','yekaterinburg','omsk','novosibirsk','barnaul','tomsk','novokuznetsk','krasnoyarsk','irkutsk','chita','yakutsk','khandyga','vladivostok','ust-nera','magadan','sakhalin','srednekolymsk','kamchatka','anadyr','riyadh','guadalcanal','mahe','khartoum','stockholm','singapore','paramaribo','juba','sao tome','el salvador','damascus','grand turk','ndjamena','kerguelen','bangkok','dushanbe','fakaofo','dili','ashgabat','tunis','tongatapu','istanbul','port of spain','funafuti','taipei','kiev','uzhgorod','zaporozhye','wake','new york','detroit','louisville','monticello','indianapolis','vincennes','winamac','marengo','petersburg','vevay','chicago','tell city','knox','menominee','center','new salem','beulah','denver','boise','phoenix','los angeles','anchorage','juneau','sitka','metlakatla','yakutat','nome','adak','honolulu','montevideo','samarkand','tashkent','caracas','ho chi minh','efate','wallis','apia','johannesburg') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'jakarta',
  `is_sent` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- 2023-07-10 01:51:27
